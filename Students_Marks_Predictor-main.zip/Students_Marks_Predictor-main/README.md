# Students_Marks_Predictor
Built a website for predicting students marks using linear regression algorithm
